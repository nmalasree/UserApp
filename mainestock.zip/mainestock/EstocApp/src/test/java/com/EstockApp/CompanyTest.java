package com.EstockApp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.EstockApp.model.Company;

public class CompanyTest {
	
	private Company company;
    @BeforeEach
    void setUp() {
        company = new Company();
    }
    @Test
    void testGetAndSetCompanyCode() {
        Long expectedCompanyCode = 1L;
        company.setCompanyCode(expectedCompanyCode);
        Long actualCompanyCode = company.getCompanyCode();
        assertEquals(expectedCompanyCode, actualCompanyCode);
    }
    @Test
    void testGetAndSetCompanyName() {
        String expectedCompanyName = "My company";
        company.setCompanyName(expectedCompanyName);
        String actualCompanyName = company.getCompanyName();
        assertEquals(expectedCompanyName, actualCompanyName);
    }
    @Test
    void testGetAndSetCompanyCEO() {
        // Arrange
        String expectedCompanyCEO = "Mala";
        company.setCompanyCEO(expectedCompanyCEO);
        String actualCompanyCEO = company.getCompanyCEO();
        assertEquals(expectedCompanyCEO, actualCompanyCEO);
    }
    @Test
    void testGetAndSetCompanyWebsite() {
        String expectedCompanyWebsite = "http://www.mycompany.com";
        company.setCompanyWebsite(expectedCompanyWebsite);
        String actualCompanyWebsite = company.getCompanyWebsite();
        assertEquals(expectedCompanyWebsite, actualCompanyWebsite);
    }
   
}

