package com.EstockApp;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.EstockApp.Repository.CompanyRepository;
import com.EstockApp.Service.CompanyImpl;
import com.EstockApp.model.Company;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
 
@SpringBootTest
public class CompanyServiceImplTest {
 
    @Mock
    private CompanyRepository companyRepo;
 
    @InjectMocks
    private CompanyImpl companyService;
 
    @Test
    public void saveCompany_ValidCompany_ReturnsSavedCompany() {
        Company companyToSave = new Company(/* Set company details here */);
        Company savedCompany = new Company(/* Set saved company details here */);
 
        Mockito.when(companyRepo.save(any(Company.class))).thenReturn(savedCompany);
 
        Company result = companyService.saveCompany(companyToSave);
 
        assertNotNull(result);
        // Add more assertions based on your requirements
    }
 
    @Test
    public void getByID_ExistingCompanyCode_ReturnsCompanyOptional() {
        long existingCompanyCode = 123L;
        Company existingCompany = new Company(/* Set existing company details here */);
 
        Mockito.when(companyRepo.findById(existingCompanyCode)).thenReturn(Optional.of(existingCompany));
 
        Optional<Company> result = companyService.getByID(existingCompanyCode);
 
        assertTrue(result.isPresent());
        // Add more assertions based on your requirements
    }
 
    @Test
    public void getAllCompanies_ReturnsListOfCompanies() {
        Company company1 = new Company(/* Set company1 details here */);
        Company company2 = new Company(/* Set company2 details here */);
 
        List<Company> companyList = Arrays.asList(company1, company2);
 
        Mockito.when(companyRepo.findAll()).thenReturn(companyList);
 
        List<Company> result = companyService.getAllCompanies();
 
        assertEquals(2, result.size());
        // Add more assertions based on your requirements
    }
 
    @Test
    public void deleteCompany_ExistingCompanyCode_DeletesCompany(){
        long existingCompanyCode = 123L;
        Company existingCompany = new Company(/* Set existing company details here */);
 
        Mockito.when(companyRepo.findById(existingCompanyCode)).thenReturn(Optional.of(existingCompany));
 
        assertDoesNotThrow(() -> companyService.deleteCompany(existingCompanyCode));
 
        Mockito.verify(companyRepo, Mockito.times(1)).deleteById(existingCompanyCode);
    }
 
    // Add more test cases for updateCompany and handle exceptions as needed
}
