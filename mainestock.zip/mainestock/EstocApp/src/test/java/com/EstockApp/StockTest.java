package com.EstockApp;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
import java.time.LocalDateTime;
 
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.EstockApp.model.Company;
import com.EstockApp.model.Stock;
 
@ExtendWith(MockitoExtension.class)
public class StockTest {
 
    @InjectMocks
    private Stock stock;
 
    @Mock
    private Company company;
 
    @Test
    void testStockCreation() {
        assertNotNull(stock);
    }
 
    @Test
    void testStockPrice() {
        Double expectedStockPrice = 50.0;
        stock.setStockPrice(expectedStockPrice);
        assertEquals(expectedStockPrice, stock.getStockPrice());
    }
 
    @Test
    void testStockDate() {
        LocalDateTime expectedDate = LocalDateTime.now();
        stock.setDate(expectedDate);
        assertEquals(expectedDate, stock.getDate());
    }
 
    @Test
    void testStockCompany() {
        stock.setCompany(company);
        assertEquals(company, stock.getCompany());
    }
 
    // Additional tests for other methods or behaviors can be added
 /*
    @Test
    void testStockIdGeneration() {
        assertNull(stock.getStockId()); // Assuming StockId is initially null
 
        // Mocking behavior for generating StockId
        when(stock.getStockId()).thenReturn(123L);
 
        assertEquals(123, stock.getStockId());
    }
    */
}

