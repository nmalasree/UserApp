package com.EstockApp.Service;

import com.EstockApp.exception.CompanyNotFoundException;
import com.EstockApp.model.Company;
import com.EstockApp.model.Stock;
import com.EstockApp.response.StockResponse;

import java.util.List;

import org.springframework.stereotype.Service;


public interface StockService {
	
	public Stock addStock(StockResponse input) throws CompanyNotFoundException;
	abstract List<Stock> getAllCompanyDetailsWithStock();

}
