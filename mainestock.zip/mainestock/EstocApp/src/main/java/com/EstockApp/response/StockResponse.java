package com.EstockApp.response;

import lombok.Data;

@Data
public class StockResponse {
	private Double stockPrice;
	private Long companyCode;

}
