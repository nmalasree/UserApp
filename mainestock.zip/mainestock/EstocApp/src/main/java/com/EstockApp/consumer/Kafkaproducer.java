package com.EstockApp.consumer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;


@Service
public class Kafkaproducer {

	@Value("marketstock-application")
    private String topicName;

    private KafkaTemplate<String, String> kafkaTemplate;

    public Kafkaproducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(String message){
        System.out.println(String.format("kafka Message sent from movie: %s", message));
        kafkaTemplate.send(topicName, message);
    }
	
}
