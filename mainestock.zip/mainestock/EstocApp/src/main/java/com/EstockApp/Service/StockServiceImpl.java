package com.EstockApp.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EstockApp.Repository.CompanyRepository;
import com.EstockApp.Repository.StockRepository;
import com.EstockApp.exception.CompanyNotFoundException;

import com.EstockApp.model.Company;
import com.EstockApp.model.Stock;
import com.EstockApp.response.StockResponse;

@Service
public class StockServiceImpl implements StockService{
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private StockRepository stockRepo; 
	
	@Override
	public Stock addStock(StockResponse input) throws CompanyNotFoundException {
		// TODO Auto-generated method stub
		Company c = companyRepo.findById(input.getCompanyCode()).orElse(null);
		updateCompanyDetails(c,input);
		if(c==null) {
			throw new CompanyNotFoundException();
		}
		Stock stock = new Stock();
		stock.setStockPrice(input.getStockPrice());
		stock.setCompany(c);
		stock.setDate(LocalDateTime.now());
		return stockRepo.save(stock);
		
	}


	
	private void updateCompanyDetails(Company c, StockResponse input) {
		// TODO Auto-generated method stub
		c.setStockPrice(input.getStockPrice());
    	companyRepo.save(c);
		
	}



	@Override
	public List<Stock> getAllCompanyDetailsWithStock() {
		// TODO Auto-generated method stub
			List<Stock> companyList= stockRepo.findAll();
			return companyList;
		}
	}

