package com.EstockApp.response;

import java.time.LocalDate;

import com.EstockApp.model.Company;
import com.EstockApp.model.Stock;


import lombok.Data;

@Data
public class CompanyResponse {
		private Long companyCode;
		private String companyName;
		private String companyCEO;
		private Long companyTurnover;
		private String companyWebsite;
		private Double stockPrice;
		private LocalDate Date;
	


}
