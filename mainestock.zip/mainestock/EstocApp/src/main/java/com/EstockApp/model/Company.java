package com.EstockApp.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Company {
	
	@Id
	@NotNull(message="Mandatory")
	@Column(name="companyCode",unique=true)
	private Long companyCode;
	@NotEmpty(message="Mandatory")
	private String companyName;
	@NotEmpty(message="Mandatory")
	private String companyCEO;
	@NotNull(message="Mandatory")
	@Min(value=100000000, message="Company Turnover should be greater than 10Cr.")
	private Long companyTurnover;
	@NotEmpty(message="Mandatory")
	private String companyWebsite;
	@Column(name="stockExchange",nullable = false)
	private String stockExchange;
	@Column(name="stockPrice",nullable = false)
	private Double stockPrice;
	//private LocalDateTime date;
	//@OneToMany(targetEntity= Stock.class)
	//private Set<Stock> stockList;
}
