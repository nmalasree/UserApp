package com.EstockApp.feignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.EstockApp.exception.IncorrectPasswordException;
import com.EstockApp.exception.UserNotFoundException;
import com.EstockApp.response.ValidateResponse;

@FeignClient(url="localhost:8083/api/v1.0/user", name="LoginApplication")
public interface UserAuthenticationClient {
	
	@PostMapping("/validate")
    public ValidateResponse validateUser(@RequestHeader("Authorization") String token) throws UserNotFoundException, IncorrectPasswordException;

}
