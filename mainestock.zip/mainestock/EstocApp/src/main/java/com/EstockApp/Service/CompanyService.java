package com.EstockApp.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.EstockApp.exception.CompanyNotFoundException;
import com.EstockApp.model.Company;

public interface CompanyService {

	abstract Company saveCompany(Company company);

	abstract Optional<Company> getByID(long companyCode);

	abstract List<Company> getAllCompanies();

	abstract  void deleteCompany(long companyCode) throws CompanyNotFoundException;
	
	public Company updateCompany(Long companyCode, Company company) throws CompanyNotFoundException;


}
