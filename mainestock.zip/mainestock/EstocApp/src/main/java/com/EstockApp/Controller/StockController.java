package com.EstockApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.EstockApp.Service.StockServiceImpl;
import com.EstockApp.exception.CompanyNotFoundException;
import com.EstockApp.exception.IncorrectPasswordException;
import com.EstockApp.exception.UserNotFoundException;
import com.EstockApp.feignClient.UserAuthenticationClient;
import com.EstockApp.model.Company;
import com.EstockApp.model.Stock;
import com.EstockApp.response.StockResponse;
import com.EstockApp.response.ValidateResponse;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {

	@Autowired
	private StockServiceImpl stockService;
	
	@Autowired
	private UserAuthenticationClient client;
	
	@PostMapping("/add/{companycode}")
	public ResponseEntity<Stock> addStock(@RequestHeader("Authorization") String token,@RequestBody StockResponse input) throws CompanyNotFoundException, UserNotFoundException, IncorrectPasswordException{
		ValidateResponse response=client.validateUser(token);
		if(response.getValid()&& response.getRoleName().contains("ADMIN")) {
		Stock s = stockService.addStock(input);
		return new ResponseEntity<>(s,HttpStatus.OK);
	}
		throw new IncorrectPasswordException("Invalid User");
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<?> getAllCompanyDetailsWithStock(@RequestHeader("Authorization") String token) throws UserNotFoundException, IncorrectPasswordException{
		ValidateResponse response=client.validateUser(token);
		if(response.getValid()) {
		List<Stock> companyList=(List<Stock>) stockService.getAllCompanyDetailsWithStock();
		return new ResponseEntity<List<Stock>>(companyList,HttpStatus.OK);
	}
		throw new IncorrectPasswordException("Invalid User");
	}

}
