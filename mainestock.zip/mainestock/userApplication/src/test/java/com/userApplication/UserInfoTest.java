package com.userApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import com.userApplication.model.*;

public class UserInfoTest {
	@Test
    public void testGetterAndSetterMethods() {
        
        UserInfo user=new UserInfo();
       
        user.setName("testUser");
        user.setEmail("test@gmail.com");
        user.setPassword("testPassword");

        // Assert using getter methods
        assertEquals("testUser", user.getName());
        assertEquals("testPassword", user.getPassword());
        assertEquals("test@gmail.com", user.getEmail());
        
    }

    @Test
    public void testSomeBusinessLogic() {
        // Arrange
    	UserInfo user=new UserInfo();
    	user.setName("testUser");
        user.setEmail("test@gmail.com");
        user.setPassword("testPassword");
    }
}
