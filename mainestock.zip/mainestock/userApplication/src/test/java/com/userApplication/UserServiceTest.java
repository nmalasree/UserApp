package com.userApplication;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.userApplication.repository.UserInfoRepository;
import com.userApplication.service.JwtService;
import com.userApplication.service.UserService;
import com.userApplication.model.*;
import com.userApplication.exceptions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
 
@SpringBootTest
public class UserServiceTest {
 
    @Mock
    private UserInfoRepository repository;
 
    @Mock
    private PasswordEncoder passwordEncoder;
 
    @Mock
    private JwtService jwtService;
 
    @InjectMocks
    private UserService userService;
 
    @Test
    public void addUser_ValidUserInfo_ReturnsSuccessMessage() {
        UserInfo userInfo = new UserInfo(/* Set user details here */);
 
        Mockito.when(passwordEncoder.encode(userInfo.getPassword())).thenReturn("encodedPassword");
        Mockito.when(repository.save(any(UserInfo.class))).thenReturn(userInfo);
 
        String result = userService.addUser(userInfo);
 
        assertEquals("user added to system ", result);
    }
    @Test
    public void validateUser_InvalidToken_ThrowsUserNotFoundException() {
        String invalidToken = "invalidToken";
 
        Mockito.when(jwtService.isTokenExpired(invalidToken)).thenReturn(true);
 
        assertThrows(UserNotFoundException.class, () -> userService.validateUser(invalidToken));
    }
 
    // Add more test cases based on your requirements
}
