package com.userApplication.dto;

public class JwtResponse {
}
