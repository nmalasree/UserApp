package com.userApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.userApplication.model.UserInfo;

@Repository
public interface UserInfoRepository extends JpaRepository<UserInfo,String> {
    @Query(value = "select u from UserInfo u where u.email= ?1")
    public UserInfo findByUserName(String email);
}
