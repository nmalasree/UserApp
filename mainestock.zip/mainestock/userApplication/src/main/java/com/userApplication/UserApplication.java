package com.userApplication;

import com.userApplication.model.UserInfo;
import com.userApplication.repository.UserInfoRepository;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;


@SpringBootApplication
public class UserApplication {
	@Autowired
	private UserInfoRepository userRepo;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@PostConstruct
	public void initRoleAndUser() {
		UserInfo adminUser = new UserInfo();
		adminUser.setName("Mala");
		adminUser.setEmail("mala@gmail.com");;
		adminUser.setPassword(getEncodedPassword("mala123"));
		adminUser.setRoles("ADMIN");
		userRepo.save(adminUser);

	}
	public String getEncodedPassword(String password) {
		return passwordEncoder.encode(password);
	}
public static void main(String[] args) {
		SpringApplication.run(UserApplication.class, args);
	}

}
