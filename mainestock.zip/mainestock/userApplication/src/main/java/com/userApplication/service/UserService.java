package com.userApplication.service;

import com.userApplication.exceptions.UserNotFoundException;
import com.userApplication.model.UserInfo;
import com.userApplication.model.ValidateResponse;
import com.userApplication.repository.UserInfoRepository;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(UserService.class);


    @Autowired
    private UserInfoRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;


    public String addUser(UserInfo userInfo) {
        userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
        repository.save(userInfo);
        return "user added to system ";
    }

    public UserInfo findById(String email) throws UserNotFoundException {
        UserInfo user = repository.findById(email).orElse(null);
        if(user == null) {
            log.error("User Not Found");
            throw new UserNotFoundException("User not found with email: "+ email);
        }
        return user;
    }

    public ValidateResponse validateUser(String token)throws UserNotFoundException  {
        // TODO Auto-generated method stub
        String email;
        UserInfo user;
        Boolean valid = jwtService.isTokenExpired(token);
        System.out.println(valid);
        if(valid==true) {
            throw new UserNotFoundException("Invalid Token!!");

        }
        System.out.println("outside claims");
        Claims claim = jwtService.extractAllClaims(token);
        System.out.println("inside claims");
        System.out.println(claim.getSubject());
        email= claim.getSubject();
        user=repository.findByUserName(email);
        if(user !=null) {
            System.out.println("inside claims13");
            ValidateResponse response = new ValidateResponse();
            response.setValid(true);
            response.setRoleName(user.getRoles());
            System.out.println("inside claims123");
            System.out.println(response);
            return response;
        }
        System.out.println("inside claims3");
        return null;
    }
}
