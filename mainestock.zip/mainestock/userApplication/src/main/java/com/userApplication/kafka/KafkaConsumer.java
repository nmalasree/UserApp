package com.userApplication.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
	@KafkaListener(topics="marketstock-application", groupId="mystock")
	public void consumeFromTopic(String message)
	{
		System.out.println("Message from Consumer is:  "+ message);
	}

}