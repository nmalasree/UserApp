package com.userApplication.controller;

import com.userApplication.dto.AuthRequest;
import com.userApplication.dto.UserRequest;
import com.userApplication.exceptions.IncorrectPasswordException;
import com.userApplication.exceptions.UserNotFoundException;
import com.userApplication.model.UserInfo;
import com.userApplication.model.ValidateResponse;
import com.userApplication.service.JwtService;
import com.userApplication.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1.0/user")
public class UserController {

    @Autowired
    private UserService service;
    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;


    @GetMapping("/welcome")
    @PreAuthorize("hasAuthority('ADMIN')")
    public String wel() {
        return "Welcome to Admin";
    }

    @PostMapping("/add")
    public String addNewUser(@RequestBody UserRequest ur) {
        UserInfo userInfo=new UserInfo(ur.getName(),ur.getEmail(),ur.getPassword(),"USER");
        return service.addUser(userInfo);
    }

    @PostMapping("/login")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        System.out.println("Insdie the login");
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {
            System.out.println("Insdie the login");
            return jwtService.generateToken(authRequest.getEmail());
        } else {
            System.out.println("Insdie the login2");
            throw new UsernameNotFoundException("invalid user request !");
        }
    }

    @GetMapping("/info/{email}")
    public ResponseEntity<?> getByEmail(@PathVariable String email) throws UserNotFoundException {
        System.out.println("Insdie the email");
        UserInfo u= service.findById(email);
        System.out.println("Insdie the emaiil1");
        return new ResponseEntity<>(u, HttpStatus.OK);
    }
    @PostMapping("/validate")
    public ResponseEntity<ValidateResponse> validateUser(@RequestHeader("Authorization") String token) throws UserNotFoundException, IncorrectPasswordException {
        System.out.println("inside validate");
        token = token.substring(7);
        ValidateResponse response = service.validateUser(token);

        return new ResponseEntity<ValidateResponse>(response,HttpStatus.OK);

    }
}
