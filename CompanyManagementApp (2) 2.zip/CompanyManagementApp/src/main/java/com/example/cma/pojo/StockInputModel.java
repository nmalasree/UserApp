package com.example.cma.pojo;

import lombok.Data;

@Data
public class StockInputModel {
	private double stockPrice;
	private Long companyCode;

}
