package com.example.cma;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.example.cma.Controller.CompanyController;
import com.example.cma.Entity.Company;
import com.example.cma.Repository.CompanyRepository;
import com.example.cma.Service.CompanyService;
import com.example.cma.serviceImpl.CompanyImpl;

//@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
class ServiceTestCases {
    
    @Autowired
    private CompanyImpl cs;
    
    @MockBean
    private CompanyRepository cr;
    
    @Mock
    private CompanyController cc;
    
    
    
  
    @Test
    public void addUserSuccess() throws Exception {
        // Create a new company object
        Company userobj = new Company();
        userobj.setCompanyCEO("hi");
        userobj.setCompanyCode(45256L);
        userobj.setCompanyName("microsoft");
        userobj.setCompanyTurnover(3253478L);
        userobj.setCompanyWebsite("afegygc.com");
        userobj.setStockExchange("nse");
        
        // Save the company object using the CompanyService
        Company savedCompany = cr.save(userobj);
        System.out.println(savedCompany);
        assertNotNull(savedCompany);
        
        // Assert that the saved company object is equal to the original company object
       // assertEquals(userobj, savedCompany);
    }
    
    
}