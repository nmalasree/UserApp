import { isNgContainer } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Stock } from './stock';
import { StockService } from './stock.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit{

  constructor(private stockService:StockService,private route:ActivatedRoute) { }

  data:{}|any;
  stockObj:Stock = new Stock();
  stock:Array<Stock>=[];
  companyCode:number;

  ngOnInit(): void {
    this.companyCode = this.route.snapshot.params['companyCode'];
  }

  stockForm= new FormGroup({
    stockPrice: new FormControl(this.stockObj.stockPrice, Validators.required),
  })

  addStock(companyCode:number)
  {
    this.stockService.addStock(this.companyCode, this.stockObj).subscribe(data=>
      {
        this.data= JSON.stringify(data);
        this.stock.push(this.data);
        alert("Stock data is added to Stock table and update to Company table");
      },
      error=>
      {
        console.log(error);
      })
  };

}
