import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Stock } from "./stock";

@Injectable({
    providedIn: 'root'
  })
  export class StockService {
  
    constructor(private http:HttpClient)
     { }
  
     private apiPostStock:string=`http://localhost:8089/api/v1.0/market/stock/add`;
     

     addStock(companyCode:number, stock:Stock):Observable<Stock>
     {
      let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
       return this.http.post<Stock>(`${this.apiPostStock}/${companyCode}`, stock,{headers:myheader});
     }
}