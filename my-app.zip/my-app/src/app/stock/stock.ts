export class Stock{
    transactionId:number|any;
    stockPrice:number|any;
    date:string|any;
    company_id_fk:number|any;
}