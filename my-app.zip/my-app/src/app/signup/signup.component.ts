import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyService } from '../company/company.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private service:CompanyService, private router:Router) { }

  public user={
    name:'',
    email:'',
    password:''
  };

  ngOnInit(): void {
  }

  errors:any;
  registrationForm= new FormGroup({
    email: new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    name: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  })

  onSubmit(){
    console.log(this.user.email);
    console.log(this.user.name);
    console.log(this.user.password);
    if(this.user.email==null||this.user.name==null||this.user.password==null||
      this.user.email==''||this.user.name==''||this.user.password==''){
        alert('Please fill up all the fields');
        return;
      }
    this.service.register(this.user).subscribe(
      (data:any)=>{
        console.log(data);
        this.errors=null
        alert('You have successfully registered');
        this.router.navigate(["login"]);
      },
      (error)=>{
        console.log(error);
        this.errors=error
        this.router.navigate(["signup"]);
      }
      )
  }
  

}
