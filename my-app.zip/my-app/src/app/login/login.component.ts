import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyService } from '../company/company.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private router:Router, private service:CompanyService){}

  errors:any;
  public login={
    email:'',
    password:''
  }
  loginForm= new FormGroup({
    email: new FormControl(this.login.email, [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    password: new FormControl(this.login.password, Validators.required),
  })


  onSubmit(){
    if(this.login.email==null||this.login.password==null||this.login.email==''||this.login.password==''){
      alert('Please fill up all the fields');
      return;
    }

    
    this.service.login(this.login).subscribe(
      (response: any)=>
      {
        console.log(response);
        this.errors=null;
        alert('Login Successfully!!');
        sessionStorage.setItem('jwtToken',response.jwtToken);
        sessionStorage.setItem('email',response.userInfo.email);
        sessionStorage.setItem('role',response.userInfo.roles);
        
        const role = response.userInfo.roles;
        console.log(role);
 
        if (role === 'ADMIN') {
 
          this.router.navigate(['/adminDashboard']);
 
        } else {
 
          this.router.navigate(['/userDashboard']);
 
        }
 
      },
       (error)=>{
        console.log(error);
        this.errors=error
        this.router.navigate(["login"]);
       }
       
    ) }
  }
