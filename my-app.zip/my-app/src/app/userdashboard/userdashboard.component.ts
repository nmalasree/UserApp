import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Company } from '../company/company';
import { CompanyService } from '../company/company.service';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  dataSource:Company[]=[];
  constructor(private companyService:CompanyService) { }

  ngOnInit(): void {
    this.companyService.getAllCompanyDetails().subscribe((data) => {
      this.dataSource = data;
    });
  }

  displayedColumns: string[] = ['companyCode', 'companyName', 'companyCEO', 'companyTurnover','companyWebsite','stockExchange','latestStockPrice'];
 
}
