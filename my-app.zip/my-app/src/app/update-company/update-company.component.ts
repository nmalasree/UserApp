import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Company } from '../company/company';
import { CompanyService } from '../company/company.service';
import { Stock } from '../stock/stock';

@Component({
  selector: 'app-update-company',
  templateUrl: './update-company.component.html',
  styleUrls: ['./update-company.component.css']
})
export class UpdateCompanyComponent implements OnInit {
  dataSource:Company[]=[];
  updateCompanyForm: any;
  companyCode: number;
  company: Company = new Company;
  constructor(private companyService:CompanyService, private router:Router,private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.companyCode = this.route.snapshot.params['companyCode'];

    this.companyService.getCompanyById(this.companyCode).subscribe(data => {
      this.company = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.companyService.updateCompany(this.companyCode, this.company).subscribe( data =>{
      this.goToCompanyList();
    }
    , error => console.log(error));
  }

  goToCompanyList(){
    this.router.navigate(['/adminDashboard']);
  }

}
