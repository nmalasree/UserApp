import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, MinLengthValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Company } from './company';
import { CompanyService } from './company.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit{

  constructor(private companyService:CompanyService ,private router:Router) {}
  ngOnInit(): void {
    // this.companyService.validate().subscribe(data=>{
    //   console.log(data);
    // })
}

  data:{}|any;
  companyObj:Company=new Company;
  companyarr:Array<Company>=[];

  // companyForm= new FormGroup({
  //   companyCode: new FormControl(this.companyObj.companyCode, Validators.required),
  //   companyName: new FormControl(this.companyObj.companyName, Validators.required),
  //   companyCEO: new FormControl(this.companyObj.companyCEO, Validators.required),
  //   companyWebsite: new FormControl(this.companyObj.companyWebsite, Validators.required),
  //   companyTurnover: new FormControl(this.companyObj.companyTurnover, Validators.required),
  //   stockExchange: new FormControl(this.companyObj.stockExchange, Validators.required),
  // })

  addCompany()
  {
    this.companyService.addCompany(this.companyObj).subscribe(data=>
      {
        this.data=JSON.stringify(data);
        this.companyarr.push(this.data);
        alert("Company added successfully");
        this.router.navigate(['adminDashboard']);
      },
      error=>
      {
          console.log(error);
      }
      )
  };

  viewAllCompanies()
  {
    this.companyService.getAllCompanyDetails().subscribe(data=>
      {
        this.companyarr=Object.values(data);
      },
      error=>
      {
        console.log(error);
      }
      )
  };

  deleteCompany(companyCode:number)
  {
    this.companyService.deleteCompany(companyCode).subscribe(data=>
      {
        let companyIndex = this.companyarr.findIndex(c=>c.companyCode===companyCode);
        this.companyarr.splice(companyIndex,1);
        alert("Company record deleted!");
        window.location.reload();
        this.viewAllCompanies();
      },
      error=>
      {
        console.log(error);
      }
      
      )
  };

  companym:Company = new Company();
  booklist:Array<Company>=[];
  response:any;
  getCompanyById()
  {
    this.companyService.getCompanyById(this.companym.companyCode).subscribe(response=>
      {
        this.response = JSON.stringify(response);
        alert("search result is given");
      })

  }

  updateCompany(companyCode:number)
  {
    
  }



}
