import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Company} from "./company";

@Injectable({
    providedIn:'root'
})
export class CompanyService{
    apiUpdate: any;
    constructor(private http:HttpClient)
    { }

    company:Company[]|any;

    private apiRegister:string="http://localhost:8085/api/v1.0/user/add";
    private apiLogin:string="http://localhost:8085/api/v1.0/user/login?msg=Admin";
    private apiValidate:string="localhost:8085/api/v1.0/user/validate";
    private apiPost:string="http://localhost:8089/api/v1.0/market/company/register";
    private apiGetAll:string="http://localhost:8089/api/v1.0/market/company/getAll";
    private apiGetById:string="http://localhost:8089/api/v1.0/market/company/info";
    private apiDelete:string="http://localhost:8089/api/v1.0/market/company/delete";
    private apiPut:string="http://localhost:8089/api/v1.0/market/company/update";

    public register(user:any){
        return this.http.post(this.apiRegister,user,{responseType: 'text' });
    }
    
    public login(request:any){
        return this.http.post(this.apiLogin,request,{responseType: 'json' });
      }
      public validate(){
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.post(this.apiValidate,{},{headers:myheader});
      }
    addCompany(companyObj:Company):Observable<Company>
    {
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.post<Company>(this.apiPost, companyObj,{headers:myheader});
    }

    getAllCompanyDetails():Observable<Array<Company>>
    {
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.get<Array<Company>>(this.apiGetAll,{headers:myheader});
    }

    getCompanyById(companyCode:number):Observable<Company>
    {
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.get<Company>(`${this.apiGetById}/${companyCode}`,{headers:myheader});
    }

    deleteCompany(companyCode:number):Observable<Company>
    {
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.delete<Company>(`${this.apiDelete}/${companyCode}`,{headers:myheader});
    }

    updateCompany(companyCode:number,companyObj:Company):Observable<Array<Company>>
    {
        let token =  sessionStorage.getItem("jwtToken");
    let myheader = new HttpHeaders({'Authorization':`Bearer ${token}`})
        return this.http.put<Array<Company>>(`${this.apiPut}/${companyCode}`,companyObj,{headers:myheader});
    }
}