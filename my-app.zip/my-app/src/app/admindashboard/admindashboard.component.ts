import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Company } from '../company/company';
import { CompanyService } from '../company/company.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {
  dataSource:Company[]=[];

  constructor(private companyService:CompanyService, private router:Router) { }

  ngOnInit(): void {
    this.companyService.getAllCompanyDetails().subscribe((data) => {
      this.dataSource = data;
    });
  }

  displayedColumns: string[] = ['companyCode', 'companyName', 'companyCEO', 'companyTurnover','companyWebsite','stockExchange','latestStockPrice','actions'];

  deleteCompany(companyCode:number)
  {
    this.companyService.deleteCompany(companyCode).subscribe(data=>
      {
        alert("Company record deleted!");
        window.location.reload();
      },
      error=>
      {
        console.log(error);
      }
      
      )
  };

  updateCompany(companyCode:number){
    this.router.navigate(['/update', companyCode]);
  }

  addStock(companyCode:number){
    this.router.navigate(['stock',companyCode]);
  }

  viewStock(companyCode:number){
    this.router.navigate(['stockdetails',companyCode]);
  }
  addCompany(){
    this.router.navigate(['company']);
  }

}
