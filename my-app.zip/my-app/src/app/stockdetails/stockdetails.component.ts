import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Company } from '../company/company';
import { CompanyService } from '../company/company.service';
import { Stock } from '../stock/stock';

@Component({
  selector: 'app-stockdetails',
  templateUrl: './stockdetails.component.html',
  styleUrls: ['./stockdetails.component.css']
})
export class StockdetailsComponent implements OnInit {
  dataSource:Stock[]=[];
  companyCode:number;
  company: Company = new Company;
  constructor(private companyService:CompanyService,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.companyCode = this.route.snapshot.params['companyCode'];

    this.companyService.getCompanyById(this.companyCode).subscribe(data => {
      this.company = data;
    });
  }

  displayedColumns: string[] = ['transactionId','company_id_fk','date','stockPrice'];

}
