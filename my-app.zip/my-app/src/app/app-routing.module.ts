import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { CompanyComponent } from './company/company.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { SignupComponent } from './signup/signup.component';
import { StockComponent } from './stock/stock.component';
import { StockdetailsComponent } from './stockdetails/stockdetails.component';
import { UpdateCompanyComponent } from './update-company/update-company.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';

const routes: Routes = [
  
  {
    path:"signup",
    component:SignupComponent,
  },
  {
    path:"login",
    component:LoginComponent,
  },
  {
    path:"company",
    component:CompanyComponent,
  },
  {
    path:"stock",
    component:StockComponent,
  },
  {
    path:"adminDashboard",
    component:AdmindashboardComponent,
  },
  {
    path:"update/:companyCode",
    component:UpdateCompanyComponent,
  },
  {
    path:"stock/:companyCode",
    component:StockComponent,
  },
  {
    path:"stockdetails/:companyCode",
    component:StockdetailsComponent,
  },
  {
    path:"userDashboard",
    component:UserdashboardComponent,
  },
  {
    path:"logout",
    component:LogoutComponent,
  },
  {
    path:"home",
    component:HomeComponent,
  },
  {
    path:"**",
    redirectTo:"/home"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
